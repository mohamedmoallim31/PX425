/*=========================================================/
/  makePNG header, PX425 2016 assignment 2.                /
/                                                          /
/  Original code created by D.Quigley - November 2012      /
/=========================================================*/


/* Function prototypes */
void writePNG(char *filname, double** grid, int width, int height);
void bork(char *msg,...);
